EJIM AI FILM STUDIOS — PLATFORM MVP

WHAT THIS VERSION DOES
- Responsive public website for the studio.
- Sections for producers, actors/voice artists, directors, writers, crew and clients.
- Member signup/login UI using Firebase Authentication (email/password).
- Member profile saving to Firestore.
- Project submission to Firestore with status "pending".
- Approved project listings can be shown publicly.
- Client enquiry form prepares an email (after you add the studio email).

IMPORTANT
The website is built, but Firebase-backed features will NOT work until you connect your own Firebase project and paste its web configuration into index.html. No payment processing or video hosting is included yet. Do not collect money or identity documents through this first version.

PUBLISH ON GITHUB PAGES USING YOUR ANDROID PHONE
1. Download and extract EJIM_AI_FILM_STUDIOS_PLATFORM_MVP.zip.
2. In GitHub, create a public repository named ejim-ai-film-studios.
3. Upload index.html to the repository's main/root folder.
4. Open Settings > Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select branch "main" and folder "/ (root)", then Save.
7. Wait for GitHub Pages to show the public website address.

CONNECT FIREBASE
1. Open https://console.firebase.google.com/ and create a project (e.g. ejim-ai-film-studios).
2. Confirm that the Web App in project nexuxai-a013d is the intended project. Its web configuration is already inserted in index.html.
5. In Firebase Authentication > Sign-in method, enable Email/Password.
6. In Firestore Database, create a database.
7. Add the following Firestore rules in the Rules tab:

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow create, update: if request.auth != null && request.auth.uid == userId;
    }
    match /projects/{projectId} {
      allow create: if request.auth != null
        && request.resource.data.ownerUid == request.auth.uid
        && request.resource.data.status == "pending";
      allow read: if resource.data.status == "approved"
        || (request.auth != null && resource.data.ownerUid == request.auth.uid);
      allow update, delete: if false;
    }
  }
}

PROJECT APPROVAL
New project submissions are marked "pending", so they do not appear publicly until reviewed and changed to "approved" in the Firebase console. This first version does not include an admin dashboard. Only approve projects you have checked.

BEFORE PUBLIC LAUNCH
- Replace REPLACE_WITH_YOUR_REAL_EMAIL in index.html with a real business email address.
- Add a real WhatsApp/contact link if desired.
- Test signup, login, profile saving and project submission.
- Add your privacy policy and terms before inviting the public.
- Never publish Firebase service-account keys or private payment credentials in front-end code. Firebase web config is intended for browser use, but Firestore security rules are essential.
- This is an early MVP, not yet a full streaming service, escrow system or guaranteed job marketplace.
